import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('DataManager')
export class DataManager extends Component {
    start() {

    }

    update(deltaTime: number) {
        
    }
}

